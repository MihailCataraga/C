//
// Created by catar on 6/10/2024.
//
#include <stdio.h>

int main() {
    for(int i = 0; i < 3; i++) {
        printf("Vreau sa programez!\n");
    }
    return 0;
}