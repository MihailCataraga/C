//
// Created by catar on 6/10/2024.
//
#include "stdio.h"

int main() {
    printf("%d", 27);
    return 0;
}
