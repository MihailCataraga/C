//
// Created by catar on 6/14/2024.
//
#include <stdio.h>

int main() {
    int x = 3;
    int res = x * x * x + x + 1;
    printf("Valuarea expresiei este %d, unde x este egal cu %d", res, x);
    return 0;
}