//
// Created by catar on 6/10/2024.
//
#include <stdio.h>

int main() {
    printf("   /\\ \n");
    printf("  /  \\ \n");
    printf(" /____\\ \n");
    printf(" |    | \n");
    printf(" |    | \n");
    printf(" |____| \n");
    return 0;
}