//
// Created by catar on 6/15/2024.
//
#include <stdio.h>

int main() {
    int latura = 6;
    int perimetru = 3 * latura;
    printf("Perimetru triunghiului echilateral cu latura de %d este: %d.", latura, perimetru);
    return 0;
}