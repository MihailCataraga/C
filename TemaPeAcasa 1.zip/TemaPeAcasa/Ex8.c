//
// Created by catar on 6/10/2024.
//
#include <stdio.h>

int main() {
    printf(":-)\n");
    printf(";-)\n");
    return 0;
}