//
// Created by catar on 6/15/2024.
//
#include <stdio.h>

int main() {
    int a = 3;
    int b = 4;
    int c = 12;
    int d = 9;
    int res = (a + b) * (c - d);
    printf("Resultatul este: %d.", res);
    return 0;
}