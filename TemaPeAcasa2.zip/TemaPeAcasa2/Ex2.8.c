//
// Created by catar on 6/15/2024.
//
#include <stdio.h>

int main() {
    int ora;

    printf("Introduceti ora actuala: ");
    scanf("%d", &ora);

    printf("Acum este ora %d.", ora);

    return 0;
}