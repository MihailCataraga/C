//
// Created by catar on 6/12/2024.
//
#include <stdio.h>

int main() {
    for (int i = 1; i < 20; i += 2) {
        printf("%d \n", i);
    }
    return 0;
}