//
// Created by catar on 6/10/2024.
//
#include <stdio.h>

int main() {
    printf("Eu am 10 mere.");
    return 0;
}