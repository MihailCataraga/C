//
// Created by catar on 6/15/2024.
//
#include <stdio.h>

int main() {
    int celsius = 23;
    int fahrenheit = (celsius * (9 / 5) + 32);
    printf("%d grade Celsius in grade Fahrenheit sunt: %d.", celsius, fahrenheit);
    return 0;
}