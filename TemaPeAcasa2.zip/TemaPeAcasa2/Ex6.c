//
// Created by catar on 6/15/2024.
//
#include <stdio.h>

int main() {
    int x = 3;
    int y = 5;
    int z = 7;
    float res = (x + y + z) / 3.0;
    printf("Media aritmetica a numerelor %d, %d, %d este: %.2f.", x, y, z, res);
    return 0;
}