//
// Created by catar on 6/10/2024.
//
#include <stdio.h>

int main() {
    const int x = 5;
    const int y = 3;
    const int z = x + y;
    printf("%d", z);
    return 0;
}