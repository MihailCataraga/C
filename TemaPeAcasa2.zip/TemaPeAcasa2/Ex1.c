//
// Created by catar on 6/13/2024.
//
#include <stdio.h>

int main() {
    int number = 27;
    float floatNumber = 27.27;
    printf("Variabila de tip int are valoarea: %d;\nVariabila de tip float are valoarea: %.2f;", number, floatNumber);
    return 0;
}