//
// Created by catar on 6/14/2024.
//
#include <stdio.h>

int main() {
    int lungimea = 6;
    int volumul =  lungimea * lungimea * lungimea;

    printf("Volumul cubului cu latura de %d este %d.", lungimea, volumul);
    return 0;
}