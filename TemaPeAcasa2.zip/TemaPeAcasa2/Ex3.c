//
// Created by catar on 6/14/2024.
//
#include <stdio.h>

int main() {
    int lungime = 9;
    int latime = 4;
    int aria = lungime * latime;
    printf("Aria dreptunghiului cu lungimea %d si latimea %d este %d.", lungime, latime, aria);
    return 0;
}