//
// Created by catar on 6/13/2024.
//
#include <stdio.h>

int main() {
    int a = 4;
    int b = 3;
    int sum = a + b;
    int dec = a - b;
    int multi = a * b;

    printf("Suma lui 4 si 3 este: %d; \nDiferenta dintre 4 si 3 este: %d; \nProdusul lui 4 si 3 este: %d;", sum, dec, multi);
    return 0;
}